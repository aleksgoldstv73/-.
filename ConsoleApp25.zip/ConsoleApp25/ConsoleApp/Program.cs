﻿using System;
using System.IO;
using System.Text.Json;
using ConsoleApp.Model;
using ConsoleApp.Model.Enum;
using ConsoleApp.OutputTypes;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Встановлюємо кодування для коректного відображення українських символів
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            try
            {
                var deliveries = JsonSerializer.Deserialize<List<Delivery>>(FileText("Dataset"))
                    ?? throw new ArgumentException("Dataset.json не знайдено або невірний формат.");
                QueryHelper helper = new QueryHelper();

                // Додано: Збільшення розміру буфера консолі
                try
                {
                    // Встановлюємо розмір буфера консолі
                    Console.BufferHeight = 15500; // Збільшуємо висоту буфера до 15500 рядків

                    // Встановлюємо BufferWidth на значення, що перевищує поточну ширину вікна
                    int desiredBufferWidth = Console.WindowWidth + 50; // Додаємо 50 символів до поточної ширини
                    if (desiredBufferWidth > Console.BufferWidth)
                    {
                        Console.BufferWidth = desiredBufferWidth;
                    }
                }
                catch (IOException ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Помилка встановлення розміру буфера: {ex.Message}");
                    Console.ResetColor();
                }

                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Виберіть завдання для виконання (1-9) або натисніть '0' для виходу:");
                    Console.WriteLine("1. Завдання 1: Знайдіть всі оплачені доставки");
                    Console.WriteLine("2. Завдання 2: Знайдіть усі доставки, що зараз опрацьовуються системою");
                    Console.WriteLine("3. Завдання 3: Сформуйте DeliveriesShortInfo з усіх доставок певного клієнта");
                    Console.WriteLine("4. Завдання 4: Поверніть перших 10 доставок певного типу, що починаються з певного міста");
                    Console.WriteLine("5. Завдання 5: Відсортуйте записи по їх статусу, якщо статуси однакові, відсортуйте за часом початку завантаження");
                    Console.WriteLine("6. Завдання 6: Підрахуйте кількість унікальних типів вантажів");
                    Console.WriteLine("7. Завдання 7: Згрупуйте доставки за їх статусом та підрахуйте кількість доставок в кожній групі");
                    Console.WriteLine("8. Завдання 8: Згрупуйте доставки за парами «місто старту-місто фінішу» та порахуйте середній проміжок між кінцем часу завантаження та початком часу прибуття");
                    Console.WriteLine("9. Завдання 9: Метод пагінації даних");
                    Console.WriteLine("0. Вихід");
                    Console.Write("Ваш вибір: ");

                    var input = Console.ReadLine();
                    if (!int.TryParse(input, out int choice) || choice < 0 || choice > 9)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Невірний вибір. Натисніть будь-яку клавішу, щоб спробувати знову.");
                        Console.ResetColor();
                        Console.ReadKey();
                        continue;
                    }

                    if (choice == 0)
                        break;

                    switch (choice)
                    {
                        case 1:
                            RunTask1(helper, deliveries);
                            break;
                        case 2:
                            RunTask2(helper, deliveries);
                            break;
                        case 3:
                            RunTask3(helper, deliveries);
                            break;
                        case 4:
                            RunTask4(helper, deliveries);
                            break;
                        case 5:
                            RunTask5(helper, deliveries);
                            break;
                        case 6:
                            RunTask6(helper, deliveries);
                            break;
                        case 7:
                            RunTask7(helper, deliveries);
                            break;
                        case 8:
                            RunTask8(helper, deliveries);
                            break;
                        case 9:
                            RunTask9(helper, deliveries);
                            break;
                    }

                    Console.WriteLine("Натисніть будь-яку клавішу, щоб повернутися до меню.");
                    Console.ReadKey();
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Помилка: {ex.Message}");
                Console.ResetColor();
                Console.WriteLine("Натисніть будь-яку клавішу, щоб закрити програму.");
                Console.ReadKey();
            }
        }

        static void RunTask1(QueryHelper helper, List<Delivery> deliveries)
        {
            var task1 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task1"))
                ?? throw new ArgumentException("task1.json не знайдено або невірний формат.");

            var actual = helper.Paid(deliveries).ToList();
            var expected = task1;

            bool result = actual.SequenceEqual(expected, new DeliveryComparer());
            PrintResult("task1", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nЗнайдено оплачених: {actual.Count}");
            Console.WriteLine("\nОплачені доставки:");
            if (actual.Any())
            {
                foreach (var delivery in actual)
                {
                    Console.WriteLine($"Id: {delivery.Id}, City: {delivery.Direction.Origin.City} -> {delivery.Direction.Destination.City}, ClientId: {delivery.ClientId}, Type: {delivery.Type}, PaymentId: {delivery.PaymentId}, Status: {delivery.Status}, CargoType: {delivery.CargoType}");
                }
            }
            else
            {
                Console.WriteLine("Немає оплачених доставок.");
            }
        }

        static void RunTask2(QueryHelper helper, List<Delivery> deliveries)
        {
            var task2 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task2"))
                ?? throw new ArgumentException("task2.json не знайдено або невірний формат.");

            var actual = helper.NotFinished(deliveries).ToList();
            var expected = task2;

            bool result = actual.SequenceEqual(expected, new DeliveryComparer());
            PrintResult("task2", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nДоставок, що в процесі: {actual.Count}");
            Console.WriteLine("\nДоставки, що зараз опрацьовуються системою:");
            if (actual.Any())
            {
                foreach (var delivery in actual)
                {
                    Console.WriteLine($"Id: {delivery.Id}, City: {delivery.Direction.Origin.City} -> {delivery.Direction.Destination.City}, Status: {delivery.Status}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок, що зараз опрацьовуються системою.");
            }
        }

        static void RunTask3(QueryHelper helper, List<Delivery> deliveries)
        {
            var task3_1 = JsonSerializer.Deserialize<List<DeliveryShortInfo>>(FileText("task3_1"))
                ?? throw new ArgumentException("task3_1.json не знайдено або невірний формат.");
            var actual1 = helper.DeliveryInfosByClient(deliveries, "f2467cf2-2f3e-4fc9-b6d8-6678ba2a29f3").ToList();
            var expected1 = task3_1;

            bool result1 = actual1.SequenceEqual(expected1, new DeliveryShortInfoComparer());
            PrintResult("task3_1", result1);

            // Вивід фактичних результатів
            Console.WriteLine($"\nСформовано DeliveriesShortInfo для клієнта: {actual1.Count}");
            Console.WriteLine("\nDeliveriesShortInfo:");
            if (actual1.Any())
            {
                foreach (var info in actual1)
                {
                    Console.WriteLine($"Id: {info.Id}, StartCity: {info.StartCity}, EndCity: {info.EndCity}, ClientId: {info.ClientId}, Type: {info.Type}, Status: {info.Status}, CargoType: {info.CargoType}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок для цього клієнта.");
            }

            var task3_2 = JsonSerializer.Deserialize<List<DeliveryShortInfo>>(FileText("task3_2"))
                ?? throw new ArgumentException("task3_2.json не знайдено або невірний формат.");
            var actual2 = helper.DeliveryInfosByClient(deliveries, "0e0b7048-cb7c-4046-9d7c-2051b07c7e05").ToList();
            var expected2 = task3_2;

            bool result2 = actual2.SequenceEqual(expected2, new DeliveryShortInfoComparer());
            PrintResult("task3_2", result2);

            // Вивід фактичних результатів
            Console.WriteLine($"\nСформовано DeliveriesShortInfo для клієнта: {actual2.Count}");
            Console.WriteLine("\nDeliveriesShortInfo:");
            if (actual2.Any())
            {
                foreach (var info in actual2)
                {
                    Console.WriteLine($"Id: {info.Id}, StartCity: {info.StartCity}, EndCity: {info.EndCity}, ClientId: {info.ClientId}, Type: {info.Type}, Status: {info.Status}, CargoType: {info.CargoType}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок для цього клієнта.");
            }
        }

        static void RunTask4(QueryHelper helper, List<Delivery> deliveries)
        {
            var task4 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task4"))
                ?? throw new ArgumentException("task4.json не знайдено або невірний формат.");

            var actual = helper.DeliveriesByCityAndType(deliveries, "Kryvyi Rih", DeliveryType.TruckOnly).ToList();
            var expected = task4;

            bool result = actual.SequenceEqual(expected, new DeliveryComparer());
            PrintResult("task4", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nПовернуто доставок: {actual.Count}");
            Console.WriteLine("\nПерші 10 доставок типу TruckOnly з міста Kryvyi Rih:");
            if (actual.Any())
            {
                foreach (var delivery in actual)
                {
                    Console.WriteLine($"Id: {delivery.Id}, City: {delivery.Direction.Origin.City} -> {delivery.Direction.Destination.City}, Type: {delivery.Type}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок відповідного типу з цього міста.");
            }
        }

        static void RunTask5(QueryHelper helper, List<Delivery> deliveries)
        {
            var task5 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task5"))
                ?? throw new ArgumentException("task5.json не знайдено або невірний формат.");

            var actual = helper.OrderByStatusThenByStartLoading(deliveries).ToList();
            var expected = task5;

            bool result = actual.SequenceEqual(expected, new DeliveryComparer());
            PrintResult("task5", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nВідсортовано доставок: {actual.Count}");
            Console.WriteLine("\nДоставки, відсортовані за статусом та часом початку завантаження:");
            if (actual.Any())
            {
                foreach (var delivery in actual)
                {
                    Console.WriteLine($"Id: {delivery.Id}, Status: {delivery.Status}, StartLoading: {delivery.LoadingPeriod.Start}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок для сортування.");
            }
        }

        static void RunTask6(QueryHelper helper, List<Delivery> deliveries)
        {
            var task6Text = FileText("task6");
            int task6;

            try
            {
                // Спробуємо десеріалізувати як просте число
                task6 = JsonSerializer.Deserialize<int>(task6Text);
            }
            catch (JsonException)
            {
                // Якщо це об'єкт, спробуємо десеріалізувати як Task6Result
                try
                {
                    var task6Obj = JsonSerializer.Deserialize<Task6Result>(task6Text);
                    task6 = task6Obj.Count;
                }
                catch (JsonException)
                {
                    throw new ArgumentException("task6.json має невірний формат.");
                }
            }

            int actual = helper.CountUniqCargoTypes(deliveries);
            bool result = actual == task6;
            PrintResult("task6", result);

            // Вивід фактичного результату
            Console.WriteLine($"\nКількість унікальних типів вантажів: {actual}");
        }

        static void RunTask7(QueryHelper helper, List<Delivery> deliveries)
        {
            var task7 = JsonSerializer.Deserialize<Dictionary<DeliveryStatus, int>>(FileText("task7"))
                ?? throw new ArgumentException("task7.json не знайдено або невірний формат.");

            var actual = helper.CountsByDeliveryStatus(deliveries)
                               .OrderBy(kv => kv.Key)
                               .ToList();
            var expected = task7.OrderBy(kv => kv.Key).ToList();

            bool result = actual.SequenceEqual(expected, new KeyValuePairComparer());
            PrintResult("task7", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nКількість доставок за статусом: {actual.Count}");
            Console.WriteLine("\nКількість доставок за статусом:");
            if (actual.Any())
            {
                foreach (var kv in actual)
                {
                    Console.WriteLine($"Status: {kv.Key}, Count: {kv.Value}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок для групування.");
            }
        }

        static void RunTask8(QueryHelper helper, List<Delivery> deliveries)
        {
            var task8 = JsonSerializer.Deserialize<List<AverageGapsInfo>>(FileText("task8"))
                ?? throw new ArgumentException("task8.json не знайдено або невірний формат.");

            var actual = helper.AverageTravelTimePerDirection(deliveries)
                               .OrderBy(a => a.StartCity)
                               .ThenBy(a => a.EndCity)
                               .ToList();
            var expected = task8.OrderBy(a => a.StartCity)
                                .ThenBy(a => a.EndCity)
                                .ToList();

            bool result = actual.SequenceEqual(expected, new AverageGapsInfoComparer());
            PrintResult("task8", result);

            // Вивід фактичних результатів
            Console.WriteLine($"\nСередній проміжок часу: {actual.Count}");
            Console.WriteLine("\nСередній проміжок часу між кінцем завантаження та початком прибуття:");
            if (actual.Any())
            {
                foreach (var info in actual)
                {
                    Console.WriteLine($"StartCity: {info.StartCity}, EndCity: {info.EndCity}, AverageGap (minutes): {info.AverageGap:F2}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок для обчислення середнього проміжку часу.");
            }
        }

        static void RunTask9(QueryHelper helper, List<Delivery> deliveries)
        {
            // Завдання 9_1
            var task9_1 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task9_1"))
                ?? throw new ArgumentException("task9_1.json не знайдено або невірний формат.");
            var actual1 = helper.Paging(
                deliveries,
                x => x.CargoType,
                x => x.Status == DeliveryStatus.InProgress).ToList();
            var expected1 = task9_1;

            bool result1 = actual1.SequenceEqual(expected1, new DeliveryComparer());
            PrintResult("task9_1", result1);

            // Вивід фактичних результатів
            Console.WriteLine($"\nПагіновані доставки за CargoType та Status == InProgress: {actual1.Count}");
            Console.WriteLine("\nПагіновані доставки:");
            if (actual1.Any())
            {
                foreach (var delivery in actual1)
                {
                    Console.WriteLine($"Id: {delivery.Id}, CargoType: {delivery.CargoType}, Status: {delivery.Status}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок, що відповідають умовам.");
            }

            // Завдання 9_2
            var task9_2 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task9_2"))
                ?? throw new ArgumentException("task9_2.json не знайдено або невірний формат.");
            var actual2 = helper.Paging(
                deliveries,
                x => x.ArrivalPeriod.Start,
                x => x.Direction.Origin.City == "Lviv").ToList();
            var expected2 = task9_2;

            bool result2 = actual2.SequenceEqual(expected2, new DeliveryComparer());
            PrintResult("task9_2", result2);

            // Вивід фактичних результатів
            Console.WriteLine($"\nПагіновані доставки за ArrivalPeriod.Start та Origin.City == Lviv: {actual2.Count}");
            Console.WriteLine("\nПагіновані доставки:");
            if (actual2.Any())
            {
                foreach (var delivery in actual2)
                {
                    Console.WriteLine($"Id: {delivery.Id}, ArrivalStart: {delivery.ArrivalPeriod.Start}, OriginCity: {delivery.Direction.Origin.City}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок, що відповідають умовам.");
            }

            // Завдання 9_3
            var task9_3 = JsonSerializer.Deserialize<List<Delivery>>(FileText("task9_3"))
                ?? throw new ArgumentException("task9_3.json не знайдено або невірний формат.");
            var actual3 = helper.Paging(
                deliveries,
                x => x.ArrivalPeriod.Start,
                x => x.Direction.Origin.City == "Lviv",
                25,
                3).ToList();
            var expected3 = task9_3;

            bool result3 = actual3.SequenceEqual(expected3, new DeliveryComparer());
            PrintResult("task9_3", result3);

            // Вивід фактичних результатів
            Console.WriteLine($"\nПагіновані доставки (page 3, 25 записів) за ArrivalPeriod.Start та Origin.City == Lviv: {actual3.Count}");
            Console.WriteLine("\nПагіновані доставки:");
            if (actual3.Any())
            {
                foreach (var delivery in actual3)
                {
                    Console.WriteLine($"Id: {delivery.Id}, ArrivalStart: {delivery.ArrivalPeriod.Start}, OriginCity: {delivery.Direction.Origin.City}");
                }
            }
            else
            {
                Console.WriteLine("Немає доставок на цій сторінці.");
            }
        }

        static string FileText(string fileName)
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Data", $"{fileName}.json");
            if (!File.Exists(path))
                throw new FileNotFoundException($"Файл {path} не знайдено.");

            using StreamReader reader = new StreamReader(path);
            return reader.ReadToEnd();
        }

        static void PrintResult(string text, bool result)
        {
            Console.ForegroundColor = result ? ConsoleColor.Green : ConsoleColor.Red;
            Console.WriteLine($"{text}: {(result ? "Passed" : "Failed")}");
            Console.ResetColor();
        }
    }

    // Компаратор для Delivery
    public class DeliveryComparer : IEqualityComparer<Delivery>
    {
        public bool Equals(Delivery x, Delivery y)
        {
            if (x == null || y == null)
                return false;
            return x.Id == y.Id &&
                   string.Equals(x.Direction.Origin?.City, y.Direction.Origin?.City, StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(x.Direction.Destination?.City, y.Direction.Destination?.City, StringComparison.OrdinalIgnoreCase) &&
                   x.Type == y.Type &&
                   x.ClientId == y.ClientId &&
                   x.Status == y.Status &&
                   string.Equals(x.CargoType, y.CargoType, StringComparison.OrdinalIgnoreCase) &&
                   Nullable.Equals(x.LoadingPeriod.Start, y.LoadingPeriod.Start) &&
                   Nullable.Equals(x.LoadingPeriod.End, y.LoadingPeriod.End) &&
                   Nullable.Equals(x.ArrivalPeriod.Start, y.ArrivalPeriod.Start) &&
                   Nullable.Equals(x.ArrivalPeriod.End, y.ArrivalPeriod.End);
        }

        public int GetHashCode(Delivery obj)
        {
            var hash = new HashCode();
            hash.Add(obj.Id);
            hash.Add(obj.Direction.Origin?.City);
            hash.Add(obj.Direction.Destination?.City);
            hash.Add(obj.Type);
            hash.Add(obj.ClientId);
            hash.Add(obj.Status);
            hash.Add(obj.CargoType);
            hash.Add(obj.LoadingPeriod.Start);
            hash.Add(obj.LoadingPeriod.End);
            hash.Add(obj.ArrivalPeriod.Start);
            hash.Add(obj.ArrivalPeriod.End);
            return hash.ToHashCode();
        }
    }

    // Компаратор для DeliveryShortInfo
    public class DeliveryShortInfoComparer : IEqualityComparer<DeliveryShortInfo>
    {
        public bool Equals(DeliveryShortInfo x, DeliveryShortInfo y)
        {
            if (x == null || y == null)
                return false;
            return x.Id == y.Id &&
                   string.Equals(x.StartCity, y.StartCity, StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(x.EndCity, y.EndCity, StringComparison.OrdinalIgnoreCase) &&
                   x.ClientId == y.ClientId &&
                   x.Type == y.Type &&
                   x.Status == y.Status &&
                   string.Equals(x.CargoType, y.CargoType, StringComparison.OrdinalIgnoreCase) &&
                   Nullable.Equals(x.LoadingPeriod.Start, y.LoadingPeriod.Start) &&
                   Nullable.Equals(x.LoadingPeriod.End, y.LoadingPeriod.End) &&
                   Nullable.Equals(x.ArrivalPeriod.Start, y.ArrivalPeriod.Start) &&
                   Nullable.Equals(x.ArrivalPeriod.End, y.ArrivalPeriod.End);
        }

        public int GetHashCode(DeliveryShortInfo obj)
        {
            var hash = new HashCode();
            hash.Add(obj.Id);
            hash.Add(obj.StartCity);
            hash.Add(obj.EndCity);
            hash.Add(obj.ClientId);
            hash.Add(obj.Type);
            hash.Add(obj.Status);
            hash.Add(obj.CargoType);
            hash.Add(obj.LoadingPeriod.Start);
            hash.Add(obj.LoadingPeriod.End);
            hash.Add(obj.ArrivalPeriod.Start);
            hash.Add(obj.ArrivalPeriod.End);
            return hash.ToHashCode();
        }
    }

    // Компаратор для KeyValuePair<DeliveryStatus, int>
    public class KeyValuePairComparer : IEqualityComparer<KeyValuePair<DeliveryStatus, int>>
    {
        public bool Equals(KeyValuePair<DeliveryStatus, int> x, KeyValuePair<DeliveryStatus, int> y)
        {
            return x.Key == y.Key && x.Value == y.Value;
        }

        public int GetHashCode(KeyValuePair<DeliveryStatus, int> obj)
        {
            var hash = new HashCode();
            hash.Add(obj.Key);
            hash.Add(obj.Value);
            return hash.ToHashCode();
        }
    }

    // Компаратор для AverageGapsInfo
    public class AverageGapsInfoComparer : IEqualityComparer<AverageGapsInfo>
    {
        public bool Equals(AverageGapsInfo x, AverageGapsInfo y)
        {
            if (x == null || y == null)
                return false;
            // Сравниваем з округленням до двох знаків після коми для точності
            return string.Equals(x.StartCity, y.StartCity, StringComparison.OrdinalIgnoreCase) &&
                   string.Equals(x.EndCity, y.EndCity, StringComparison.OrdinalIgnoreCase) &&
                   Math.Abs(x.AverageGap - y.AverageGap) < 0.1; // Точність до 0.1
        }

        public int GetHashCode(AverageGapsInfo obj)
        {
            var hash = new HashCode();
            hash.Add(obj.StartCity);
            hash.Add(obj.EndCity);
            hash.Add(Math.Round(obj.AverageGap, 1)); // Округлення для відповідності
            return hash.ToHashCode();
        }
    }

    // Доповнення: Клас для десеріалізації task6.json, якщо це необхідно
    public class Task6Result
    {
        public int Count { get; set; }
    }
}
