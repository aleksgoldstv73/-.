﻿using ConsoleApp.Model;
using ConsoleApp.Model.Enum;
using ConsoleApp.OutputTypes;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp
{
    public class QueryHelper : IQueryHelper
    {
        /// <summary>
        /// Завдання 1: Знайдіть всі оплачені доставки
        /// </summary>
        public IEnumerable<Delivery> Paid(IEnumerable<Delivery> deliveries)
            => deliveries.Where(d => !string.IsNullOrWhiteSpace(d.PaymentId));

        /// <summary>
        /// Завдання 2: Знайдіть усі доставки, що зараз опрацьовуються системою (тобто не скасовані і не виконані)
        /// </summary>
        public IEnumerable<Delivery> NotFinished(IEnumerable<Delivery> deliveries)
            => deliveries.Where(d => d.Status != DeliveryStatus.Cancelled && d.Status != DeliveryStatus.Done);

        /// <summary>
        /// Завдання 3: Сформуйте DeliveriesShortInfo з усіх доставок певного клієнта
        /// </summary>
        public IEnumerable<DeliveryShortInfo> DeliveryInfosByClient(IEnumerable<Delivery> deliveries, string clientId)
            => deliveries
                .Where(d => d.ClientId.Equals(clientId, StringComparison.OrdinalIgnoreCase))
                .Select(d => new DeliveryShortInfo
                {
                    Id = d.Id,
                    StartCity = d.Direction.Origin?.City,
                    EndCity = d.Direction.Destination?.City,
                    ClientId = d.ClientId,
                    Type = d.Type,
                    LoadingPeriod = d.LoadingPeriod,
                    ArrivalPeriod = d.ArrivalPeriod,
                    Status = d.Status,
                    CargoType = d.CargoType
                });

        /// <summary>
        /// Завдання 4: Поверніть перших 10 доставок певного типу, що починаються з певного міста.
        /// </summary>
        public IEnumerable<Delivery> DeliveriesByCityAndType(IEnumerable<Delivery> deliveries, string cityName, DeliveryType type)
            => deliveries
                .Where(d => string.Equals(d.Direction.Origin?.City, cityName, StringComparison.OrdinalIgnoreCase) && d.Type == type)
                .OrderBy(d => d.Id) // Можна змінити на інший критерій сортування
                .Take(10);

        /// <summary>
        /// Завдання 5: Відсортуйте записи по їх статусу, якщо статуси однакові, відсортуйте за часом початку завантаження (за зростанням)
        /// </summary>
        public IEnumerable<Delivery> OrderByStatusThenByStartLoading(IEnumerable<Delivery> deliveries)
            => deliveries
                .OrderBy(d => d.Status)
                .ThenBy(d => d.LoadingPeriod.Start);

        /// <summary>
        /// Завдання 6: Підрахуйте кількість унікальних типів вантажів
        /// </summary>
        public int CountUniqCargoTypes(IEnumerable<Delivery> deliveries)
            => deliveries
                .Select(d => d.CargoType)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();

        /// <summary>
        /// Завдання 7: Згрупуйте доставки за їх статусом та підрахуйте кількість доставок в кожній групі. Результат подати у вигляді словника
        /// </summary>
        public Dictionary<DeliveryStatus, int> CountsByDeliveryStatus(IEnumerable<Delivery> deliveries)
            => deliveries
                .GroupBy(d => d.Status)
                .ToDictionary(g => g.Key, g => g.Count());

        /// <summary>
        /// Завдання 8: Згрупуйте доставки за парами «місто старту-місто фінішу» та порахуйте середній проміжок між кінцем часу завантаження та початком часу прибуття.
        /// </summary>
        public IEnumerable<AverageGapsInfo> AverageTravelTimePerDirection(IEnumerable<Delivery> deliveries)
            => deliveries
                .Where(d => d.Direction.Origin?.City != null
                         && d.Direction.Destination?.City != null
                         && d.LoadingPeriod.End.HasValue
                         && d.ArrivalPeriod.Start.HasValue
                         && d.ArrivalPeriod.Start.Value >= d.LoadingPeriod.End.Value)
                .GroupBy(d => new { StartCity = d.Direction.Origin.City, EndCity = d.Direction.Destination.City })
                .Select(g => new AverageGapsInfo
                {
                    StartCity = g.Key.StartCity,
                    EndCity = g.Key.EndCity,
                    AverageGap = g.Average(d => (d.ArrivalPeriod.Start.Value - d.LoadingPeriod.End.Value).TotalMinutes)
                });

        /// <summary>
        /// Завдання 9: Метод пагінації даних
        /// </summary>
        public IEnumerable<TElement> Paging<TElement, TOrderingKey>(IEnumerable<TElement> elements,
            Func<TElement, TOrderingKey> ordering,
            Func<TElement, bool>? filter = null,
            int countOnPage = 100,
            int pageNumber = 1)
            => (filter == null ? elements : elements.Where(filter))
                .OrderBy(ordering)
                .Skip((pageNumber - 1) * countOnPage)
                .Take(countOnPage);
    }
}
