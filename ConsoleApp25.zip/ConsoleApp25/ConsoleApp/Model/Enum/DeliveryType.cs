﻿namespace ConsoleApp.Model.Enum;

public enum DeliveryType
{
    TruckOnly = 0,
    TruckAndTrailer = 1
}