﻿namespace ConsoleApp.Model;

public record Address
{
    public string? City { get; set; }
}